import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ElectronicComponent } from './electronic/electronic.component';
// import { ProductDetailsComponent } from './product-details/product-details.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductsComponent } from './products/products.component';
import { ProductDetailsComponent } from './product-details/product-details.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
//   {path:'electronic',component:ElectronicComponent,
//   children:[{path:'sidebar',component:SidebarComponent}]
// },
  {path:'product-list/:id',component:ProductListComponent, //{
  // {path:'product-list/:id/:sid',component:ProductListComponent,
  children:[
    {path:'products/:cid/:sid',component:ProductsComponent},
    {path:'details/:cid/:sid/:pid',component:ProductDetailsComponent}
  ]
},
  
  {path:'**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
