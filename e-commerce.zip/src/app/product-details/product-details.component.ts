import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
catID;
subCatID;
product;
  constructor(private route:ActivatedRoute, private productService:ProductService) { }

  ngOnInit() {

    this.route.paramMap.subscribe(params =>{
      this.catID=params.get('cid');
      this.subCatID=params.get('sid');
      const pid=params.get('pid');
      this.productService.getProducts().subscribe(products =>{
        const productsList = products[this.catID][this.subCatID];
        for(let obj of productsList)
        {
          if(obj.product_id == pid)
          this.product = obj;
        }
      })
    });
  }

}
