import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
catID;
subCatID;
productList;

  constructor(private route:ActivatedRoute,private productService:ProductService) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params =>{
      this.catID = params.get('cid');
      this.subCatID=params.get('sid');
      this.productService.getProducts().subscribe(products =>
      {
        this.productList = products[this.catID][this.subCatID];
      });
    });
  }

}
