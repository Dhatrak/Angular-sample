import { Component, OnInit, Input } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
subCategories;
  constructor(private productService:ProductService) { }

  @Input('catID') public catID;

  ngOnChanges()
  {
    console.log("cat id: "+this.catID);
    this.productService.getCategories().subscribe(data=>{
      
      for(let cat of data)
       {
        if(cat.category_id == this.catID)
        {
          this.subCategories=cat.sub_categories;
        }
      }
    })
  }
  ngOnInit() {
   console.log("cat id: "+this.catID);
  }

}
