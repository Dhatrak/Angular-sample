import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
categories=[];

  constructor(private productService:ProductService) { }

  ngOnInit() {
    this.productService.getCategories().subscribe(data=>{
      this.categories=data;
    });
  }

}
