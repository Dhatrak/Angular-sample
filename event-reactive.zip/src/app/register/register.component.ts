import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { EventService } from '../event.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  rform:FormGroup;
  name;
  email;
  pass;
  mobile;
  city;
  constructor(private fb:FormBuilder,private eventService:EventService) { }

  ngOnInit() {
    this.rform = this.fb.group({
      name: ['',Validators.compose([Validators.required,
      Validators.minLength(5), Validators.maxLength(20)])],
      mobile: [''],
      city: [''],
      email: ['',Validators.compose([Validators.required,Validators.email])],
      passw: ['',Validators.compose([Validators.required,])],
      
      
    });
  }
  registers()
{
  console.log(this.rform);
}
get f()
{
  return this.rform.controls;
}
register()
{
  let rform = {
    name:this.name,
    mobile:this.mobile,
    city:this.city,
    email:this.email,
    pass:this.pass,
  
  }
  this.eventService.register(rform);
  this.name="";
  this.mobile="";
  this.city="";
  this.email="";
  this.pass="";
  
}

}
