import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor() { }
  
  register(rform)
  {
    var users : any[]=JSON.parse(localStorage.getItem('users'));
    if(users)
    {
      users.push(rform);
      localStorage.setItem('users',JSON.stringify(users));
    }else
    {
      var users = [];
      users.push(rform);
      localStorage.setItem('users',JSON.stringify(users));
    }
  }

}
