import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
loginStatus=false;

  constructor(private service:StudentService) { }

  ngOnInit() {

  }
  ngDoCheck()
  {
    this.loginStatus = this.service.isLoggedIn;
    console.log("is Login: "+this.loginStatus);
  }
logout()
{
  this.service.logout();
}
}
