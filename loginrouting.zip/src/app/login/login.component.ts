import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
email;
pass;
  constructor(private service:StudentService,private router:Router) { }
  
login()
{
 const loginState = this.service.login(this.email,this.pass);

 if(loginState)
 {
   this.router.navigate(['/profile']);
 }else
 {
  alert("Invalid Username or Password");
 }
  }
  
ngOnInit() {
  }

}
