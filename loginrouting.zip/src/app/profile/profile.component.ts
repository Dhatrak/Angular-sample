import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
myname="Welcome to Toppers skill";

  constructor(private service:StudentService,private router:Router) { }

  
  ngOnInit() {
  }
  
  logout()
  {
    this.router.navigate(['/login']);
  }

}
