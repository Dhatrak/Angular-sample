import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  name;
  email;
  pass;
  constructor(private service:StudentService) { }

  register()
  {
    let obj = {
      name:this.name,
      email:this.email,
      pass:this.pass,
    }
    this.service.register(obj);
    this.name="";
    this.email="";
    this.pass="";
  }
  ngOnInit() {
  }

}
