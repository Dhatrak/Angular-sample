import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
isLoggedIn:boolean=false;

  constructor(private router:Router) { }

  register(obj)
  {
    var users : any[]=JSON.parse(localStorage.getItem('users'));
    if(users)
    {
      users.push(obj);
      localStorage.setItem('users',JSON.stringify(users));
      alert("Register Successfully..!");
  
    }else
    {
      var users = [];
      users.push(obj);
      localStorage.setItem('users',JSON.stringify(users));
      alert("User already created...");
    }
  }
  // Login(obj)
  // {
  //   var users = JSON.parse(localStorage.getItem('users'));
  //   if(users)
  //   {
  //     for(var user of users)
  //     {
  //       if(user.email == obj.email && user.pass == obj.pass)
  //       {
  //         var flag=1;
  //       }
  //     }
  //     if(flag == 1)
  //     alert("Login Successfull");
  //     else
  //     alert("Invalid Username or Password! Please try again.");
      
  //   }
  //   else
  //   alert("Data not Found");
  
  // }
  
 public login(email:string,pass:string): boolean
  {
    const users = JSON.parse(localStorage.getItem("users"));
    for(let user of users)
    {
      if(user.email == email && user.pass == pass)
      {
        this.isLoggedIn=true;
        alert("Login Successfully");
        break;
      }
    }
    return this.isLoggedIn;
  }

  public logout()
  {
    this.isLoggedIn = false;
    this.router.navigate(['/login']);
  }
}


