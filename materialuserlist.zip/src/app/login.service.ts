import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  public username : string;
  public password : string;
  isLogin :boolean = false;
  isLoggedIn:boolean=false;
  
  loginDetails = {
    username:'admin', 
    password:'admin123', 
  };
  constructor() {
    // localStorage.setItem('loginDetails',JSON.stringify(this.loginDetails));
   }

 


  // userValidate(loginDetails):boolean{
  //   var  loginobj=localStorage.getItem('loginDetails');
  //   var  loginstring = JSON.parse(loginobj);
  //   var storedname=loginstring.username;
  //   var storedpass=loginstring.password;
    

  //   if(this.loginDetails.username == storedname && this.loginDetails.password == storedpass){
  //     alert('Please Fill The');
  //     return this.isLogin = true;
  //     return true;

  //   }else{
  //     alert("Incorrect Username or Password");
  //     return this.isLogin = false;
  //     return false;
  //   }
 
  // }



// ------------------------------------------


// *******************example1*****************************
public login(username:string,password:string): boolean
{
  const loginDetails = JSON.parse(localStorage.getItem("loginDetails"));
  for(let user of loginDetails)
  {
    if(user.username == username && user.password == password)
    {
      this.isLoggedIn=true;
      alert("Login Successfully");
      break;
    }
  }
  return this.isLoggedIn;

}
// *******************************************************


// login(username: string, password : string)
//   {
// if(username == "admin" && password =="admin123"){
// localStorage.setItem('username',"admin");
// return true;
// }
// else{
//   return false;
// }
//   }






}
