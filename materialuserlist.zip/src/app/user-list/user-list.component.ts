import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

export interface PeriodicElement {
  name: string;
  mobile: string;
  email: string;
  pancard: string;
  city:string;
  country:string;
  id:number;
  designation:string;
}
// const ELEMENT_DATA: PeriodicElement[] = [
//   {position:1,name:"Gayatri",mobile:"77777777777",email:"gay@gmail.com",pancard:"APDG4545K",city:"Pune",country:"India"},
//       {position:2,name:"Monali",mobile:"77777777777",email:"gay@gmail.com",pancard:"APDG4745K",city:"Nashik",country:"India"},
//       {position:3,name:"Chhaya",mobile:"7410544710",email:"cgh@gmail.com",pancard:"ACDG4525K",city:"Pune",country:"India"},
//       {position:4,name:"Swati",mobile:"77777777777",email:"swati@gmail.com",pancard:"APDG4565K",city:"Nashik",country:"India"},
//   ];

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})



export class UserListComponent implements OnInit {
  userlist=[];
  displayedColumns: string[] = ['id', 'name', 'mobile','email', 'pancard','city','country','designation',];
  dataSource = this.userService.userlist;
  constructor( private userService:UserService) { }

  ngOnInit() {
    // this.userlist = this.userService.getUserList();
  }

  // deleteUser(i){
  //   this.userlist.splice(i,1);
  // }

}