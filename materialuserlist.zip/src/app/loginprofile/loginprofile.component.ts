import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginprofile',
  templateUrl: './loginprofile.component.html',
  styleUrls: ['./loginprofile.component.css']
})
export class LoginprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
