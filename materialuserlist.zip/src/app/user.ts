export interface User {
    id:number;
    name: string;
    mobile: string;
    email: string;
    pancard: string;
    city:string;
    country:string;
    designation:string;
}
