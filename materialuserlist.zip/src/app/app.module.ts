import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from './material/material.module';
import { LoginprofileComponent } from './loginprofile/loginprofile.component';
import { MenuComponent } from './menu/menu.component';
import { AddUserComponent } from './add-user/add-user.component';
import { UserListComponent } from './user-list/user-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { MatMenu, MatMenuContent, MatMenuItem, MatMenuTrigger, MatMenuModule } from '@angular/material';
// const material = [
//   MatMenu,
//   MatMenuContent,
//   MatMenuItem,
//   MatMenuTrigger,
//   MatMenuModule,
// ]
@NgModule({
  // imports: [material],
  // exports:[material],
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    LoginprofileComponent,
    MenuComponent,
    AddUserComponent,
    UserListComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    
    // MatMenu,
    // MatMenuContent,
    // MatMenuItem,
    // MatMenuTrigger,
    // MatMenuModule,
    // material
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
