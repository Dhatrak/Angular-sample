import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {
  name: string;
  mobile: string;
  email: string;
  pancard: string;
  city:string;
  country:string;
  id:number;
  designation:string;

  userlist=[];

  constructor(private userService:UserService) { }

  ngOnInit() {
  }
addUserlist()
{
  let obj: User ={
    id:this.id,
    name: this.name,
    mobile: this.mobile,
    email: this.email,
    pancard: this.pancard,
    city:this.city,
    country:this.country,
    designation:this.designation
  
  }
  this.userService.addUser(obj);
  alert("User Added Successfully!");
}

}
