import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { LoginprofileComponent } from './loginprofile/loginprofile.component';
import { MenuComponent } from './menu/menu.component';
import { NavbarComponent } from './navbar/navbar.component';
import { UserListComponent } from './user-list/user-list.component';
import { AddUserComponent } from './add-user/add-user.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  {path:'', redirectTo: 'login', pathMatch: 'full'},
  // {path:'menu',component:MenuComponent},
  {path:'login',component:LoginComponent},
  {path:'loginprofile',component:LoginprofileComponent},
  {path:'navbar',component:NavbarComponent,
  children:[
  {path:'user-list',component:UserListComponent},
  {path:'add-user',component:AddUserComponent},
  {path:'dashboard',component:DashboardComponent}
  ]},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
