import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userlist =[
    {id:1,name:"Gayatri",mobile:"7410528965",email:"gay@gmail.com",pancard:"APDG4545K",city:"Pune",country:"India",designation:"Software Developer"},
    {id:2,name:"Monali",mobile:"9877885522",email:"gay@gmail.com",pancard:"APDG4745K",city:"Nashik",country:"India",designation:"Software Engineer"},
    {id:3,name:"Chhaya",mobile:"7410545710",email:"cgh@gmail.com",pancard:"ACDG4525K",city:"Pune",country:"India",designation:"Mean Stack Developer"},
    {id:4,name:"Swati",mobile:"9874105447",email:"swati@gmail.com",pancard:"APDG4565K",city:"Nashik",country:"India",designation:"System Engineer"},
  ];

  constructor() { }

  public getUserList(){
    return this.userlist;
  }
  public addUser(user){
    this.userlist.push(user);
  }


}

