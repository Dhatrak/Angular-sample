import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
// import { EventEmitter } from 'protractor';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  mform: FormGroup
  
  public username : string;
  public password : string;
  isLogin :boolean =false;
  logDetails ={
    username:"admin",
    password:"admin123"
  };
  msg;
  // submit() {
  //   if (this.mform.valid) {
  //     this.submitEM.emit(this.mform.value);
  //   }
  // }
  // @Input() error: string | null;

  // @Output() submitEM = new EventEmitter();
  constructor(private fb:FormBuilder,private router:Router,private loginService:LoginService,private route:ActivatedRoute) { }
  // login()
  // {
  //  const loginState = this.loginService.login(this.username,this.password);
  
  //  if(loginState)
  //  {
  //    this.router.navigate(['/loginprofile']);
  //  }else
  //  {
  //   alert("Invalid Username or Password");
  //  }
  //   }
  //******************************** */

//   ************************************************
formSubmit(){
  if(this.logDetails.username == "" && this.logDetails.password == ""){
    this.isLogin=true;
    alert("Invalid Username");
    // this.router.navigate(['/navbar']);
  }
  else
  {
    alert("Successfull login");
    this.router.navigate(['/navbar']);
  }
 
}
// ********************************************************


// formSubmit(username: string, password : string)
// {
//   var output = this.loginService.login(username, password);
//   if(output == true)
//   {
//     this.router.navigate(['/navbar']);
//   }
//   else{
// this.msg ='Invalid username or password';
//   }
// }











  ngOnInit() {
    // this.mform = this.fb.group({
    //   username: ['',Validators.compose([Validators.required,])],
    //   password: ['',],
    // });
  }
  // loginForm(){
  
  //   if(this.isLogin = !this.loginService.userValidate({username:this.username, password:this.password})){
  //     if(this.username=="" && this.password==""){
  //       this.router.navigate(['/navbar']);
  //     }else{
  //       this.router.navigate(['/loginprofile']);
  //     }
  //   }

  // }




}