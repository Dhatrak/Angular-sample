import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-addbook',
  templateUrl: './admin-addbook.component.html',
  styleUrls: ['./admin-addbook.component.css']
})
export class AdminAddbookComponent implements OnInit {

  ISBNCode : string;
  bookName : string;
  catagory : string;
  edition : string;
  author : string;
  publisher : string;
  bdate : string;
  constructor(private bookService:AdminService) { }

  ngOnInit() {
  }

  addData(){
    this.bookService.addBook({ISBNCode:this.ISBNCode, bookName:this.bookName, catagory:this.catagory, edition:this. edition, author:this.author, publisher:this.publisher, bdate:this.bdate});
  }

}
