import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-booklist',
  templateUrl: './admin-booklist.component.html',
  styleUrls: ['./admin-booklist.component.css']
})
export class AdminBooklistComponent implements OnInit {

  booklist=[];

  constructor( private bookService:AdminService) { }

  ngOnInit() {
    this.booklist = this.bookService.getBooklist();
  }

  deleteBook(i){
    this.booklist.splice(i,1);
  }

}
