import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminAddbookComponent } from './admin-addbook/admin-addbook.component';
import { AdminBooklistComponent } from './admin-booklist/admin-booklist.component';
import { StudBooklistComponent } from './stud-booklist/stud-booklist.component';

const routes: Routes = [
  {path:'', redirectTo: '/mainpage', pathMatch: 'full'},
  {path:'mainpage', component:MainpageComponent},
  {path:'sidebar', component:SidebarComponent},
  {path:'login', component:LoginComponent},
  {path:'register', component:RegisterComponent},
  {path:'booklist', component:AdminBooklistComponent},
  {path:'addbook', component:AdminAddbookComponent},
  {path:'studbooklist', component:StudBooklistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
