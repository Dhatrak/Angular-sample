import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

booklist =[
    {ISBNCode:"978-1-13-123453-0", bookName:"Yash Tumachya Hatat", catagory:"General Knowledge", edition:"4rd generation", author:"Shiv Khera", publisher:"jon Thonus",  bdate:"12 March 2019"},
    {ISBNCode:"978-2-23-65879-0", bookName:"Baji Prabhu", catagory:"Historical", edition:"4rd generation", author:"320",  publisher:"10 March 2018",  bdate:"12 March 2019"},
    {ISBNCode:"978-3-09-09876-0", bookName:"Shivaji MAharaj", catagory:"Historical", edition:"4rd generation", author:"320",  publisher:"10 March 2018",  bdate:"12 March 2019"},
    {ISBNCode:"978-4-54-21435-0", bookName:"Sambhaji MAharaj", catagory:"Historical", edition:"4rd generation", author:"320",  publisher:"10 March 2018",  bdate:"12 March 2019"},
  ];

  constructor() { }

  public getBooklist(){
    return this.booklist;
  }
  public addBook(book){
    this.booklist.push(book);
  }

  

}
