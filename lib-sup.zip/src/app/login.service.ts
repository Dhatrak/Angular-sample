import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

public username : string;
public password : string;
isLogin :boolean = false;

  loginInfo = 
    {username:'supriya', password:'supriya123', email:'supriya@gmail.com', role:'librarian'};
  

  constructor() { 
    localStorage.setItem('loginInfo',JSON.stringify(this.loginInfo));
  }

  userValidate(loginInfo):boolean{
    var  loginobj=localStorage.getItem('loginInfo');
    var  loginstring = JSON.parse(loginobj);
    var storedname=loginstring.username;
    var storedpass=loginstring.password;
    

    if(this.loginInfo.username == storedname && this.loginInfo.password == storedpass){
      alert('Please Fill The');
      return this.isLogin = true;
      return true;
    }else{
      alert("invalid username or password.");
      return this.isLogin = false;
      return false;
    }
 
  }

  logout(){
    this.isLogin=false;
  }

}
