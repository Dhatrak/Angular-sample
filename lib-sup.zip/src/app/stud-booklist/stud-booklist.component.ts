import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-stud-booklist',
  templateUrl: './stud-booklist.component.html',
  styleUrls: ['./stud-booklist.component.css']
})
export class StudBooklistComponent implements OnInit {

  booklist=[];

  constructor( private bookService:AdminService) { }

  ngOnInit() {
    this.booklist = this.bookService.getBooklist();
  }

}
