import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AdminBooklistComponent } from './admin-booklist/admin-booklist.component';
import { AdminAddbookComponent } from './admin-addbook/admin-addbook.component';
import { StudBooklistComponent } from './stud-booklist/stud-booklist.component';
import { SearchbookComponent } from './searchbook/searchbook.component';

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    MainpageComponent,
    LoginComponent,
    RegisterComponent,
    AdminBooklistComponent,
    AdminAddbookComponent,
    StudBooklistComponent,
    SearchbookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
