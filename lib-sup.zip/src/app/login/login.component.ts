import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isShow : boolean = true;
  isHide : boolean = false;

  public username : string;
  public password : string;
  isLogin :boolean =false;

  constructor( private logService : LoginService, private route:Router) { }

  ngOnInit() {
  }

  forgotPassword(){
    this.isShow= !this.isShow;
    this.isHide= !this.isHide;
  }

  loginForm(){
    // if(this.isLogin==true){
    //   if(this.username=="" || this.password==""){
    //     this.isLogin = true;
    //     this.route.navigate(['/login']);
    //   }
    //   // console.log(this.isLogin = this.logService.userValidate({username:this.username, password:this.password}));
    // }else{
    //   alert('Please Fill The All Deatails..');
    //   this.route.navigate(['/sidebar']);
    //   this.isLogin = true;
    // }
    // alert(this.isLogin = this.logService.userValidate({username:this.username, password:this.password}));

    if(this.isLogin = !this.logService.userValidate({username:this.username, password:this.password})){
      if(this.username=="" && this.password==""){
        this.route.navigate(['/login']);
      }else{
        this.route.navigate(['/sidebar']);
      }
    }

  }

}
